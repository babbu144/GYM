// src/main/java/com/gms/model/Batch.java
package com.gms.model;

public class Batch {
    private int id;
    private String name;
    private String time;

    public Batch(int id, String name, String time) {
        this.id = id;
        this.name = name;
        this.time = time;
    }

    // Getters and Setters
    // ...
}
