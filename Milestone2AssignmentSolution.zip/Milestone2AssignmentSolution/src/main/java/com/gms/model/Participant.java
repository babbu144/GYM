// src/main/java/com/gms/model/Participant.java
package com.gms.model;

public class Participant {
    private int id;
    private String name;
    private String phone;
    private String email;
    private int batchId;

    public Participant(int id, String name, String phone, String email, int batchId) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.batchId = batchId;
    }

    // Getters and Setters
    // ...
}
