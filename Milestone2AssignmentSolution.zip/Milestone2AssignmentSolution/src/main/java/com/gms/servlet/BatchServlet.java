// src/main/java/com/gms/servlet/BatchServlet.java
package com.gms.servlet;

import com.gms.dao.BatchDAO;
import com.gms.model.Batch;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class BatchServlet extends HttpServlet {
    private BatchDAO batchDAO = new BatchDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle adding a new batch
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle updating a batch
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle deleting a batch
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle retrieving batches
    }
}
