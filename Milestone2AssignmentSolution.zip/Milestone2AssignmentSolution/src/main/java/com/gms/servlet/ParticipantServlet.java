// src/main/java/com/gms/servlet/ParticipantServlet.java
package com.gms.servlet;

import com.gms.dao.ParticipantDAO;
import com.gms.model.Participant;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class ParticipantServlet extends HttpServlet {
    private ParticipantDAO participantDAO = new ParticipantDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle adding a new participant
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle updating a participant
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle deleting a participant
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle retrieving participants
    }
}
