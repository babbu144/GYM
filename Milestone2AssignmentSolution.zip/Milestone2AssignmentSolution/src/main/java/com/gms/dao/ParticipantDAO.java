// src/main/java/com/gms/dao/ParticipantDAO.java
package com.gms.dao;

import com.gms.model.Participant;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ParticipantDAO {
    // Implement CRUD methods for Participant using JDBC
}
