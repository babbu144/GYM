-- db_setup.sql
CREATE DATABASE zumbaDB;

USE zumbaDB;

CREATE TABLE Participant (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50),
    phone VARCHAR(15),
    email VARCHAR(50),
    batch_id INT
);

CREATE TABLE Batch (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50),
    time VARCHAR(20)
);
